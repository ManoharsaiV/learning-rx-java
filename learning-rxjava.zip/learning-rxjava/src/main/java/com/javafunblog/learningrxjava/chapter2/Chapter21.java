package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;

public class Chapter21 {

    public static void main(String[] args) {
        Observable<String> source = Observable.create(emitter -> {
            emitter.onNext("Alpha");
            emitter.onNext("Beta");
            emitter.onNext("Gamma");
            emitter.onComplete();
        });

        Observable<String> source2 = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(@NonNull ObservableEmitter<String> emitter) throws Throwable {
                emitter.onNext("Alpha-2");
                emitter.onNext("Beta-2");
                emitter.onNext("Gamma-2");
                emitter.onComplete();
            }
        });


        source.subscribe(s -> System.out.println("RECEIVED: " + s));
        source2.subscribe(s -> System.out.println("RECEIVED: " + s));


        Observable<String> source3 = Observable.create(emitter -> {
            try {
                emitter.onNext("Alpha-3");
                emitter.onNext("Beta-3");
                emitter.onNext("Gamma-3");
                emitter.onNext("");
                emitter.onComplete();
            } catch (Throwable e) {
                emitter.onError(e);
            }
        });


        // rather than doing this in multiple Observables
        // you can chain them because
        // each Observable here internally acts as an Observer to send the data
        Observable<Integer> lengths = source3.map(String::length);
        Observable<Integer> filteredLengths = lengths.filter(i -> i >= 7);

        // so, we can do something as follows
        Observable<Integer> filLengths = source3.map(String::length).filter(l -> l >= 7);


        source3.subscribe(s -> System.out.println("RECEIVED: " + s),
                Throwable::printStackTrace);

//        filteredLengths.subscribe(s -> System.out.println(s), Throwable::printStackTrace);
        filLengths.subscribe(s -> System.out.println("RECEIVED: " + s), Throwable::printStackTrace);








    }

}
