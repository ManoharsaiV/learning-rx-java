package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;

/**
 * interface SingleObserver<T> {
 * void onSubscribe(@NonNull Disposable d);
 * void onSuccess(T value);
 * void onError(@NonNull Throwable error);
 * }
 */

public class Chapter228 {
    public static void main(String[] args) {
        Single.just("hello")
                .map(String::length)
                .subscribe(System.out::println, e -> System.out.println("error captured! " + e));

        // There are operators on Single that turn it into an Observable, such as toObservable().
        // And, in the opposite direction, certain Observable operators return a Single

        Observable<String> stringObservable = Observable.just("Alpha", "Beta");
        Single<String> stringSingle = stringObservable.first("Nil");
        stringSingle.subscribe(System.out::println);
    }
}
