package com.javafunblog.learningrxjava.chapter4;

import io.reactivex.rxjava3.core.Observable;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Chapter41MergingFactoriesAndOperators {


    /**
     * To summarize, Observable.merge() combines multiple Observable<T> sources emitting the same type T
     * and consolidates them into a single Observable<T>. It works on infinite Observable instances
     * and does not necessarily guarantee that the emissions come in any order.
     * If you care about the emissions being strictly ordered by having each Observable
     * source fired sequentially, consider using Observable.concat(), which we will cover shortly.
     */
    public static void main(String[] args) {
//        mergingUsingFactories();
//        mergingUsingOperator();
//        mergingMoreThanFourObservables();
//        combiningMoreThanFourObservablesUsingIterable();

       /* mergingTwoObservablesWithDifferent();
        //keep alive for 3 seconds
        sleep(3000);*/
        flatMapFun();
        sleep(30000);
    }


    // The Observable.merge() factory and the mergeWith() operator will subscribe to
    // all the specified sources simultaneously, but will likely fire the emissions in order
    // if they are cold and on the same thread.
    // This is just an implementation detail that is not guaranteed to work the same way every time.
    // ie., order may or may not be preserved
    public static void mergingUsingFactories() {
        // Using Factories
        // Observable.merge()
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Zeta", "Eta");
        Observable.merge(src1, src2)
                .subscribe(i -> System.out.println("RECEIVED: " + i));

    }

    public static void mergingUsingOperator() {
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Zeta", "Eta");
        src1.mergeWith(src2)
                .subscribe(i -> System.out.println("RECEIVED: " + i));
    }

    // You should not rely on ordering when using merge factories and operators,
    // even if ordering seems to be preserved. Having said that, the order of emissions
    // from each source Observable is maintained. The way the sources are merged is an
    // implementation detail, so use concatenation factories and operators if you want to guarantee order.

    // There is also an overloaded version of Observable.merge() that
    // accepts Iterable<Observable<T>> and produces the same results in a more type-safe manner:
    public static void mergingMoreThanFourObservables() {
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Gamma", "Delta");
        Observable<String> src3 = Observable.just("Epsilon", "Zeta");
        Observable<String> src4 = Observable.just("Eta", "Theta");
        Observable<String> src5 = Observable.just("Iota", "Kappa");
        Observable.mergeArray(src1, src2, src3, src4, src5)
                .subscribe(i -> System.out.println("RECEIVED: " + i));

    }

    public static void combiningMoreThanFourObservablesUsingIterable() {
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Gamma", "Delta");
        Observable<String> src3 = Observable.just("Epsilon", "Zeta");
        Observable<String> src4 = Observable.just("Eta", "Theta");
        Observable<String> src5 = Observable.just("Iota", "Kappa");
        List<Observable<String>> sources =
                Arrays.asList(src1, src2, src3, src4, src5);
        Observable.merge(sources)
                .subscribe(i -> System.out.println("RECEIVED: " + i));
    }

    public static void mergingTwoObservablesWithDifferent() {
        Observable<String> src1 = Observable.interval(1,
                TimeUnit.SECONDS)
                .map(l -> {
                    System.out.println(l);
                    return l + 1;
                }) // emit elapsed seconds
                .map(l -> "Source1: " + l + " seconds");
        //emit every 300 milliseconds
        Observable<String> src2 =
                Observable.interval(300, TimeUnit.MILLISECONDS)
                        .map(l -> {
                            System.out.println(l);
                            return (l + 1) * 300;
                        }) // emit elapsed milliseconds
                        .map(l -> "Source2: " + l + " milliseconds");
        //merge and subscribe
        Observable.merge(src1, src2)
                .subscribe(System.out::println);

    }

    // The flatMap() operator is one of, if not the, most powerful operators in RxJava.
    // If you have to invest time in understanding any RxJava operator, this is the one.
    // It performs a dynamic Observable.merge() by taking each emission and mapping it
    // to an Observable. Then, it merges the resulting observables into a single stream.

    public static void flatMapFun() {
        Observable<String> source =
                Observable.just("521934/2342/FOXTROT",
                        "21962/12112/TANGO/78886");
        source.flatMap(s -> Observable.fromArray(s.split("/")))
                .filter(s -> !s.matches("[A-Z]+"))
                .map(s -> Integer.valueOf(s))
                .subscribe((I) -> System.out.println(I));


        /*Observable.just(2, 3, 10, 7)
                .flatMap(i -> Observable.interval(i, TimeUnit.SECONDS)
                        .map(i2 -> i + "s interval: " +
                                ((i2 + 1) * i) + " seconds elapsed"))
                .subscribe(System.out::println);*/

        Observable.just(2, 0, 3, 10, 7)
                .flatMap(i -> {
                    if (i == 0) {
                        return Observable.empty();
                    } else {
                        return Observable.interval(i, TimeUnit.SECONDS)
                                .map(l -> i + "s interval: " +
                                        ((l + 1) * i) + " seconds elapsed");
                    }
                })
                .subscribe(System.out::println);

    }


    private static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
