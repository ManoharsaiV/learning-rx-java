package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

import java.util.concurrent.TimeUnit;

public class Chapter217 {
    public static void main(String[] args) {
        Observable.interval(1, TimeUnit.SECONDS).subscribe(s -> System.out.println(s));
        sleep(4000);
    }

    private static void sleep(int duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
