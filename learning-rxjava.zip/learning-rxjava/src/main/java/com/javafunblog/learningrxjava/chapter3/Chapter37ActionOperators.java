package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Notification;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.Disposable;

import java.util.concurrent.TimeUnit;

public class Chapter37ActionOperators {

    public static void main(String[] args) {
        Observable.just("Alpha", "Beta", "Gamma")
                .doOnNext(s -> System.out.println("Processing: " + s))
                .map(String::length)
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .doAfterNext(s -> System.out.println("After: " + s))
                .map(String::length)
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .doOnComplete(() ->
                        System.out.println("Source is done emitting!"))
                .map(String::length)
                .subscribe(i -> System.out.println("Received: " + i));


        System.out.println();
        Observable.just(5, 2, 4, 0, 3, 2, 8)
                .doOnError(e -> System.out.println("Source failed!"))
                .map(i -> 10 / i)
                .doOnError(e -> System.out.println("Division failed!"))
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));


        System.out.println();

        Observable.just("One", "Two", "Three")
                .doOnEach(s -> System.out.println("doOnEach: " + s))
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();
        Observable.just("One", "Two", "Three")
                .doOnEach(s -> System.out.println("doOnEach: " +
                        s.isOnNext() + ", " + s.isOnError() +
                        ", " + s.isOnComplete() + " " + (s instanceof Notification ? true : false)))
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();
        Observable.just("One", "Two", "Three")
                .doOnEach(s -> System.out.println("doOnEach: " +
                        s.getError() + ", " + s.getValue()))
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .doOnSubscribe(d -> System.out.println("Subscribing!"))
                .doOnDispose(() -> System.out.println("Disposing!"))
                .subscribe(i -> System.out.println("RECEIVED: " + i));

        // doOnDispose() was not called. That is because the dispose() method was not called.

        System.out.println();
        Disposable disp = Observable.interval(1, TimeUnit.SECONDS)
                .doOnSubscribe(d -> System.out.println("Subscribing!"))
                .doOnDispose(() -> System.out.println("Disposing!"))
                .subscribe(i -> System.out.println("RECEIVED: " + i));

        sleep(3000);
        disp.dispose();
        sleep(3000);

        // doFinally() operator,
        // which will fire after either onComplete() or onError() is called or disposed of by the chain

        System.out.println();
        Observable.just("One", "Two", "Three")
                .doFinally(() -> System.out.println("doFinally!"))
                .doAfterTerminate(() ->
                        System.out.println("doAfterTerminate!"))
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();



        Disposable disp2 = Observable.interval(1, TimeUnit.SECONDS)
                .doOnSubscribe(d -> System.out.println("Subscribing!"))
                .doOnDispose(() -> System.out.println("Disposing!"))
                .doFinally(() -> System.out.println("doFinally!"))
                .doAfterTerminate(() ->
                        System.out.println("doAfterTerminate!"))
                .subscribe(i -> System.out.println("RECEIVED: " + i));

        sleep(4000);
        disp2.dispose();
        sleep(4000);

//        The doFinally() operator guarantees that the action is executed exactly once per subscription.

    }


    private static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
