package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Chapter33TransformingOperators {
    public static void main(String[] args) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("M/d/yyyy");
        Observable.just("1/3/2016", "5/9/2016", "10/12/2016")
                .map(s -> LocalDate.parse(s, dateTimeFormatter))
                .subscribe(s -> System.out.println(s), (e) -> System.out.println("Exception caught: " + e), () -> System.out.println("done"));
        // The map() operator does a one-to-one conversion of each emitted value.
        // If you need to do a one-to-many conversion (turn one emission into several emissions),
        // you can use flatMap() or concatMap(), which we will cover in the next chapter.

        // what you can also do with map()
        Observable<Object> items = Observable.just("Alpha", "Beta", "Gamma").map(s -> (Object) s);

        // we can use cast()
        Observable<Object> objectObservable = Observable.just("Alpha", "Beta", "Gamma").cast(Object.class);

        // startWithItem(String) --> 3.0
        // startWith(not String) --> 2.0

        Observable<String> menu = Observable.just("TEA", "COFFEE", "ESPRESSO", "LATTE");

        menu.startWith(Single.just("CAFÉ DISCO!")).subscribe(System.out::println);

        System.out.println();

        menu.startWithItem("CAFÉ MENU!").subscribe(s -> System.out.println(s));

        // startWithArray()
        System.out.println();

        menu.startWithArray("CAFÉ MEÑŪ!", "---------").subscribe(System.out::println);


        System.out.println();

        List<String> list =
                Arrays.asList("COFFEE SHOP MENU", "----------------");
        menu.startWithIterable(list).subscribe(System.out::println);


        System.out.println();

        // sorted() for finite streams only
        Observable.just(6, 2, 5, 7, 1, 4, 9, 8, 3)
                .sorted()
                .subscribe(System.out::print);

        //Of course, this can have some performance implications and consumes the memory as it collects all emitted values
        // in memory before emitting them again. If you use this against an infinite Observable,
        // you may even get an OutOfMemoryError exception.

        System.out.println();

        Observable.just(6, 2, 5, 7, 1, 4, 9, 8, 3)
                .sorted(Comparator.reverseOrder())
                .subscribe(System.out::print);

        System.out.println();
        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .sorted(Comparator.comparingInt(String::length))
                .subscribe(System.out::println);

        System.out.println();

        Observable.just(3, 4, 5)
                .scan((accumulator, i) -> accumulator + i)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();
        // Note that scan() is very similar to reduce(), which we will learn about shortly. Be careful not to confuse them though.
        // The scan() operator emits the rolling accumulation for each emission, whereas reduce()
        // yields a single result reflecting the final accumulated value after onComplete() is called.
        // This means that reduce() has to be used with a finite Observable only, while the scan() operator can be
        // used with an infinite Observable too.

        Observable.just("Sai Manohar", "Veerubhotla", "Hare Krishna", "Sri Hari", "Sriman Narayana")
                .scan((result, s) -> result.concat(" ").concat(s).concat(" "))
                .subscribe(System.out::println);

        // You can also provide an initial value for the first argument and aggregate the emitted values into a different
        // type than what is being emitted. If we wanted to emit the rolling count of emissions,
        // we could provide an initial value of 0 and just add 1 to it for every emitted value.

        // Keep in mind that the initial value would be emitted first, so use skip(1) after scan()
        // if you do not want that initial emission to be included in the accumulator:
        System.out.println();
        Observable.just("Alpha", "Beta", "Gamma")
                .scan(0, (total, next) -> total + 1)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .scan(0, (total, next) -> total + 1).skip(1)
                .subscribe(s -> System.out.println("Received: " + s));


    }
}
