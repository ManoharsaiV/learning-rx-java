package com.javafunblog.learningrxjava.chapter4;

import io.reactivex.rxjava3.core.Observable;

public class Chapter42ConcatenatingFactoriesAndOperators {
    /**
     * Concatenation is remarkably similar to merging, but with an important nuance:
     * it emits items of each provided Observable sequentially and in the order specified.
     * It does not move on to the next Observable until the current one calls onComplete().
     * This makes it great to ensure that the merged Observable starts emitting in a
     * guaranteed order. However, it is often a poor choice for infinite Observable,
     * as it will indefinitely hold up the queue and forever leave the Observable that
     * is next in line waiting.
     **/

    public static void concatWithFactory() {
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Zeta", "Eta");
        Observable.concat(src1, src2)
                .subscribe(i -> System.out.println("RECEIVED: " + i));

    }

    public static void concatWithOperator() {
        Observable<String> src1 = Observable.just("Alpha", "Beta");
        Observable<String> src2 = Observable.just("Zeta", "Eta");
        src1.concatWith(src2)
                .subscribe(i -> System.out.println("RECEIVED: " + i));
    }
    /**
     * If we use Observable.concat() with infinite observables, it will forever emit from
     * the first one it encounters and prevent any following Observable from firing.
     * If we ever want to put an infinite Observable anywhere in a concatenation operation,
     * it should be listed last.
     * This ensures that it does not hold up any Observable following it because there are none.
     * We can also use take() operators to make an infinite Observable finite.
     *  */

    


}
