package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

// subscribe with only onNext
public class Chapter210 {
    public static void main(String[] args) {
        Observable<String> source =
                Observable.just("Alpha", "Beta", "Gamma");
        source.map(String::length)
                .filter(i -> i >= 5)
                .subscribe(i -> System.out.println("RECEIVED: " + i));
    }
}
