package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;

import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class Chapter35CollectionOperators {


    public static void main(String[] args) {
        //  toList()
        //
        //    The toList() is probably the most often used among all the collection operators.
        //    For a given Observable<T>, it collects incoming items into a List<T> and then pushes that List<T> object
        //    as a single value through Single<List<T>.
        //
        //    In the following code snippet, we collect String values into a List<String>.
        //    After the preceding Observable signals onComplete(), that list is pushed into the Observer to be printed:
        Observable.just("Alpha", "Beta", "Gamma")
                .toList()
                .subscribe(s -> System.out.println("Received: " + s));


        // By default, toList() uses an ArrayList implementation of the List interface.
        // You can optionally specify an integer argument to serve as the capacityHint value that optimizes the
        // initialization of the ArrayList to expect roughly that number of items:
        Observable.range(1, 5)
                .toList(10)
                .subscribe(s -> System.out.println("Received: " + s));

        // If you want to use a different List implementation, you can provide a Callable function as an argument to specify one.
        // In the following code snippet, we provide a CopyOnWriteArrayList instance to serve as a List implementation:
        Observable.just("Beta", "Gamma", "Alpha")
                .toList(CopyOnWriteArrayList::new)
                .subscribe(s -> System.out.println("Received: " + s));

        // toSortedList()

        // A different flavor of toList() operator is toSortedList().
        // It collects the emitted values into a List object that has the elements sorted in a natural order
        // (based on their Comparable implementation).
        // Then, it pushes that List<T> object with sorted elements into the Observer:

        Observable.just("Beta", "Gamma", "Alpha")
                .toSortedList()
                .subscribe(s -> System.out.println("Received: " + s));


        Single<Map<Character, String>> mapSingle = Observable.just("Alpha", "Beta", "Gamma")
                .toMap(s -> s.charAt(0));

        mapSingle.subscribe(System.out::println);


        // If we decide to yield a different value other than the received one to associate with the key,
        // we can provide a second lambda argument that maps each received value to a different one.
        // We can, for instance, map each first letter key with the length of the received String object:

        System.out.println();
        Observable.just("Alpha", "Beta", "Gamma")
                .toMap(s -> s.charAt(0), s -> s.length())
                .subscribe(System.out::println);


        // By default, toMap() uses the HashMap class as the Map interface implementation.
        // You can also provide a third argument to specify a different Map implementation.
        // For instance, we can provide ConcurrentHashMap instead of HashMap as the desired implementation of the Map interface:

        Observable.just("Alpha", "Beta", "Gamma")
                .toMap(s -> s.charAt(0), String::length,
                        ConcurrentHashMap::new)
                .subscribe(s -> System.out.println("Received: " + s));


        // Note that if there is a key that maps to multiple received values, the last value for that key is going to replace the previous ones.
        // For example, let's make the string length the key for each received value.
        // Then, Alpha is going to be replaced by Gamma:
        Observable.just("Alpha", "Beta", "Gamma")
                .toMap(String::length)
                .subscribe(s -> System.out.println("Received: " + s));


        // If you want a given key to map to multiple values, you can use toMultiMap() instead,
        // which maintains a list of corresponding values for each key.
        // The items Alpha and Gamma will then all be put in a list that is keyed off the length 5:
        Observable.just("Alpha", "Beta", "Gamma")
                .toMultimap(String::length)
                .subscribe(s -> System.out.println("Received: " + s));

        Observable.just("Alpha", "Beta", "Gamma")
                .toMultimap(String::length, s -> s, TreeMap::new)
                .subscribe(s -> System.out.println("Received: " + s));

        // When none of the collection operators can do what you need, you can always use the collect() operator to specify a different type to collect items into.
        //
        //For instance, there is no toSet() operator to collect emissions in a Set<T>,
        // but you can quickly use collect(Callable<U> initialValueSupplier, BiConsumer<U,T> collector) to effectively do this.

        // Let's say you need to collect String values in a Set<String> implementation.
        // To accomplish that, you can specify the first argument—the function that produces an initial value
        // of the Set<String> implementation you would like to use, and the second argument—the function that
        // is going to collect the values (whatever you need to collect) in that Set<String> implementation you have chosen.
        // Here is the code that uses HashSet<String> as the Set<String> implementation:
        Single<TreeSet<String>> setSingle = Observable.just("Alpha", "Beta", "Alpha", "Beta", "Gamma")
                .collect(TreeSet::new, TreeSet::add);


        setSingle.subscribe(System.out::println);

        // When you need to collect values into a mutable object and you need a new mutable object seed each time,
        // use collect() instead of the reduce() operator.







    }

}
