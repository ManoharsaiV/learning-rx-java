package com.javafunblog.learningrxjava.chapter2;


import io.reactivex.rxjava3.core.Maybe;
import io.reactivex.rxjava3.core.Observable;

/*
public interface MaybeObserver<T> {
      void onSubscribe(@NonNull Disposable d);
      void onSuccess(T value);
      void onError@NonNull Throwable e);
      void onComplete();
}
* */
public class Chapter230 {
    //But if there are 0 or 1 emissions, you should use Maybe instead.

    // A given Maybe<T> emits 0 or 1 items. It will pass the possible emission to onSuccess(),
    // Maybe.just() can be used to create a Maybe emitting a single item.
    // Maybe.empty() creates a Maybe that emits nothing:
    // and only in case of Maybe.empty(), it will call onComplete() when done.

    public static void main(String[] args) {
        Maybe<Integer> maybe = Maybe.just(100);

        //The message Process 1 done! does not come up because there is no ambiguity: the Maybe observable cannot emit more than one item, so it is completed implicitly.
        maybe.subscribe(s -> System.out.println(s), e -> System.out.println("error captured: " + e), () -> System.out.println("Process 1 done!"));

        //no emission
        Maybe<Integer> empty = Maybe.empty();
        empty.subscribe(s -> System.out.println("Process 2: " + s),
                e -> System.out.println("Error captured: " + e),
                () -> System.out.println("Process 2 done!"));


        // has emission
        // Now, the onComplete event was issued to tell the Observer that it should not expect anything else.
        Observable<Integer> source = Observable.just(100);
        source.subscribe(s -> System.out.println("Process 1:" + s),
                e -> System.out.println("Error captured: " + e),
                () -> System.out.println("Process 1 done!"));
        //no emission
        Observable<Integer> observableEmpty = Observable.empty();
        empty.subscribe(s -> System.out.println("Process 2:" + s),
                e -> System.out.println("Error captured: " + e),
                () -> System.out.println("Process 2 done!"));


        // Certain Observable operators that we will discuss later yield a Maybe.
        // One example is the firstElement() operator, which is similar to first(), but returns an empty result if no elements are emitted:
        Observable<String> stringObservable =
                Observable.just("Alpha", "Beta");
        stringObservable.firstElement()
                .subscribe(s -> System.out.println("RECEIVED " + s),
                        e -> System.out.println("Error captured: " + e),
                        () -> System.out.println("Done!"));
        // Please note that the onComplete event was not generated this time because the Observable has no idea that the processing has stopped after the first emission.


    }
}
