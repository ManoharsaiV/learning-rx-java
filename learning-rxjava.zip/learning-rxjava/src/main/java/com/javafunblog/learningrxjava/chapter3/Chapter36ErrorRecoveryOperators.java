package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Observable;

import java.util.concurrent.TimeUnit;

public class Chapter36ErrorRecoveryOperators {

    public static void main(String[] args) {
      /*  Observable.just(5, 4, 3, 2, 0)
                .map(i -> 10 / i)
                .subscribe(i -> System.out.println("Received: " + i),
                        e -> System.out.println("Received Error: " + e));*/

        // the emissions stopped after the error anyway, but the error itself did not flow down to the Observer.
        // Instead, the value -1 was received by it as if emitted by the source Observable.
        Observable.just(5, 4, 3, 2, 0, 3)
                .map(i -> 10 / i)
                .onErrorReturnItem(-1)
                .subscribe(i -> System.out.println("Received: " + i),
                        e -> System.out.println("Received Error: " + e));


        Observable.just(5, 4, 3, 2, 0, 3)
                .map(i -> 10 / i)
                .onErrorReturn(e -> e instanceof ArithmeticException ? -1 : 0)
                .subscribe(i -> System.out.println("Received: " + i),
                        e -> System.out.println("Received Error: " + e));


        // If you want to resume emissions, you can handle the error within the map() operator where the error occurs.

        Observable.just(5, 4, 3, 2, 0, 3)
                .map(i -> {
                    try {
                        return 10 / i;
                    } catch (ArithmeticException e) {
                        return -1;
                    }
                })
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));

        System.out.println();
        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .onErrorResumeWith(Observable.just(-1).repeat(3))
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));

        System.out.println();

        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .onErrorResumeWith(Observable.empty())
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));

        System.out.println();

        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .retry(2) // you can use retry() -> which retries infinite times
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));


        System.out.println();

        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .retryWhen(attempts -> attempts.zipWith(Observable.range(1, 3), (n, i) -> i).flatMap(i -> {
                    System.out.println("delay retry by " + i + " second(s)");
                    return Observable.timer(i, TimeUnit.SECONDS);
                })) // you can use retry() -> which retries infinite times
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));

        sleep(5000);





    }

    private static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
