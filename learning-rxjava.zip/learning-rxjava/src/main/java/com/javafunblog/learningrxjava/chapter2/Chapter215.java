package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

public class Chapter215 {
    public static void main(String[] args) {
        Observable.range(1, 3)
                .subscribe(s -> System.out.println(s));

        Observable.range(5, 3)
                .subscribe(s -> System.out.println(s));



    }

}
