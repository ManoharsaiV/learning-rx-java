package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.MaybeObserver;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Timed;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

public class Chapter38UtilityOperators {

    public static void main(String[] args) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("hh:MM:ss");
        System.out.println(LocalDateTime.now().format(dateTimeFormatter));

        // here the emission from the source Observable was delayed by 3 seconds.
        Observable.just("Alpha", "Beta", "Gamma")
                .delay(3, TimeUnit.SECONDS)
                .subscribe(s -> System.out.println(LocalDateTime.now().format(dateTimeFormatter) +
                        "RECEIVED: " + s));

        sleep(5000);

        // Because delay() operates on a different scheduler (such as Observable.interval()),
        // we need to use the sleep(long ms) method to keep the application
        // alive long enough to see this happen (5 seconds in our case).

        System.out.println();

        Observable.just("Alpha", "Beta", "Gamma")
                .repeat(2)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();

        Observable.just("One")
                .single("Four")
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();

        Observable.fromMaybe(MaybeObserver::onComplete)
                .single("Four")
                .subscribe(i -> System.out.println("Received: " + i));

        System.out.println();

        Observable.just("One", "Two", "Three")
                .timestamp(TimeUnit.SECONDS)
                .subscribe(i -> System.out.println("Received: " + i));


        // As you can see, the results are wrapped inside the object of the Timed class,
        // which provide accessors to the values that we can unwrap as follows

        System.out.println();
        Observable.just("One", "Two", "Three")
                .timestamp(TimeUnit.SECONDS)
                .subscribe(i -> System.out.println("Received: " +
                        i.time() + " " + i.unit() + " " + i.value() + " " + (i instanceof Timed)));

        System.out.println();

        Observable.interval(2, TimeUnit.SECONDS)
                .doOnNext(i -> System.out.println("Emitted: " + i))
                .take(3)
                .timeInterval(TimeUnit.SECONDS)
                .subscribe(i -> System.out.println("Received: " + i));
        sleep(7000);


    }

    private static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
