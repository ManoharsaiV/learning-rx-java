package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Observable;


public class Chapter31ConditionalOperators {

    public static void main(String[] args) {

        Observable<Integer> integerObservable = Observable.range(1, 100);

//        ConnectableObservable<Integer> integerObservableC = Observable.range(1,100).publish();

        integerObservable
                .takeWhile(i -> i < 5)
                .subscribe(i -> System.out.println("RECEIVED 1: " + i));

        integerObservable.take(5)
                .subscribe(i -> System.out.println("RECEIVED 2: " + i));

/*
        integerObservableC.take(5)
                .subscribe(i-> System.out.println("RECEIVED 3: "+ i));

        integerObservableC.connect();


        integerObservableC.takeWhile(i -> i < 10)
                .subscribe(i-> System.out.println("RECEIVED 4: "+ i));

        integerObservableC.connect();*/

        Observable.range(1, 100)
                .skipWhile(i -> i <= 95)
                .subscribe(i -> System.out.println("RECEIVED: " + i));

        Observable<String> items = Observable.just("Alpha", "Beta");

        items.filter(s -> s.startsWith("Z"))
                .defaultIfEmpty("None")
                .subscribe(System.out::println);

        // Of course, if the preceding Observable is not empty, then switchIfEmpty() will have no effect and that second specified Observable will not be used.
        Observable.just("Alpha", "Beta", "Gamma")
                .filter(s -> s.startsWith("Z"))
                .switchIfEmpty(Observable.just("Zeta", "Eta", "Theta"))
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR: " + e));


    }


}
