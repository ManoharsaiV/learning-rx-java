package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

// You can also provide the exception using a lambda expression
// so that it is created from scratch and a separate exception instance is provided to each Observer.
public class Chapter223 {
    public static void main(String[] args) {
        Observable.error(() -> new Exception("Crash and burn!"))
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("Error captured: " + e),
                        () -> System.out.println("Done!"));
    }

}
