package com.javafunblog.learningrxjava.chapter3;

import io.reactivex.rxjava3.core.Observable;

import java.time.LocalDate;

public class Chapter34ReducingOperators {

    // Note that nearly all of these operators only work on a finite Observable that calls onComplete() because,
    // typically, we can aggregate only finite datasets.


    public static void main(String[] args) {
        // count()
        // The count() operator counts the number of emitted items and emits the result through a Single once onComplete() is called.
        Observable.just("Alpha", "Beta", "Gamma")
                .count()
                .subscribe(s -> System.out.println("Received: " + s));

        // The reduce() operator is syntactically identical to scan(), but it only emits the final result when the source Observable
        // calls onComplete(). Depending on which overloaded version is used, it can yield Single or Maybe.
        // If you need the reduce() operator to emit the sum of all emitted integer values, for example,
        // you can take each one and add it to the rolling total. But it will only emit once—after the
        // last emitted value is processed (and the onComplete event is emitted):

        System.out.println();
        Observable.just(5, 3, 7)
                .reduce((total, i) -> total + i)
                .subscribe(s -> System.out.println("Received: " + s));

        // Similar to scan(), there is a seed argument that you can provide that will serve as the initial value to accumulate on.
        // If we wanted to turn our emissions into a single comma-separated String value, we could use reduce(), too,
        // as shown in the following example:

        System.out.println();
        Observable.just(5, 3, 7)
                .reduce(10, (total, i) -> total + i)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();
        Observable.just(5, 3, 7)
                .reduce("", (total, i) ->
                        total + (total.equals("") ? "" : ",") + i)
                .subscribe(s -> System.out.println("Received: " + s));

        // Your seed value for the reduce() operator should be immutable, such as an integer or String.
        // Bad side effects can happen if it is mutable. In such cases, you should use collect() (or seedWith()),
        // which we will cover in a moment.


        System.out.println();
        // There is a sub-category of reducing operators that evaluate the result to a boolean value and return a Single<Boolean> object.
        // The all() operator verifies that all emissions meet the specified criterion and returns a Single<Boolean> object.
        // If they all pass, it returns the Single<Boolean> object that contains true.
        // If it encounters one value that fails the criterion, it immediately calls onComplete() and returns the object that contains false.
        // In the following code snippet, we test six (or fewer) integers, verifying that they all are less than 10:

        // When the all() operator encountered 11, it immediately emitted false and called onComplete().
        // It did not even receive 2 or 14 because that would be unnecessary work.
        // It has already found an element that fails the test.
        Observable.just(5, 3, 7, 11, 2, 14)
                .all(i -> i < 10)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();

        // If you call all() on an empty Observable, it will emit true due to the principle of vacuous truth.

        // The any() method checks whether at least one emission meets a specified criterion and returns a Single<Boolean>.
        // The moment it finds an emission that does, it returns a Single<Boolean> object with true and then calls onComplete().
        // If it processes all emissions and finds that none of them meet the criterion,
        // it returns a Single<Boolean> object with false and calls onComplete().

        // If you call any() on an empty Observable, it will emit false due to the principle of vacuous truth.

        // When it encountered the 2016-09-12 date, it immediately emitted true and called onComplete().
        // It did not proceed to process 2016-04-03.
        Observable.just("2016-01-01", "2016-05-02",
                "2016-09-12", "2016-04-03")
                .map(LocalDate::parse)
                .any(dt -> dt.getMonthValue() >= 6)
                .subscribe(s -> System.out.println("Received: " + s));

        System.out.println();

        // The isEmpty() operator checks whether an Observable is going to emit more items.
        // It returns a Single<Boolean> with true if the Observable does not emit items anymore.
        //
        //In the following code snippet, an Observable emits strings, and neither contain the letter z.
        // The following filter, however, only allows a downstream flow of those items that do contain the letter z.
        // This means that, after the filter, the Observable emits no items (becomes empty),
        // but if the letter z is found in any of the emitted strings, the received result changes to false,
        // as demonstrated in the following example:

        Observable.just("One", "Two", "Three")
                .filter(s -> s.contains("z"))
                .isEmpty()
                .subscribe(s -> System.out.println("Received1: " + s));

        Observable.just("One", "Twoz", "Three")
                .filter(s -> s.contains("z"))
                .isEmpty()
                .subscribe(s -> System.out.println("Received2: " + s));


        // The contains() operator checks whether a specified item (based on the hashCode()/equals() implementation)
        // has been emitted by the source Observable. It returns a Single<Boolean> with true if the specified item was emitted,
        // and false if it was not.

        Observable.range(1, 10000)
                .contains(9563)
                .subscribe(s -> System.out.println("Received: " + s));

        // As you have probably guessed, the moment the specified value is found, the operator returns Single<Boolean> with true,
        // calls onComplete(), and disposes of the processing pipeline.
        // If the source calls onComplete() and the element was not found, it returns Single<Boolean> with false.


        // sequenceEqual()

        // The sequenceEqual() operator checks whether two observables emit the same values in the same order.
        // It returns a Single<Boolean> with true if the emitted sequences are the same pairwise.
        //
        //In the following code snippet, we create and then compare observables that emit the same sequence
        // or different (by order or by value) sequences:

        System.out.println();

        Observable<String> obs1 = Observable.just("One", "Two", "Three");
        Observable<String> obs2 = Observable.just("One", "Two", "Three");
        Observable<String> obs3 = Observable.just("Two", "One", "Three");
        Observable<String> obs4 = Observable.just("One", "Two");

        Observable.sequenceEqual(obs1, obs2)
                .subscribe(s -> System.out.println("Received: " + s));

        Observable.sequenceEqual(obs1, obs3)
                .subscribe(s -> System.out.println("Received: " + s));

        Observable.sequenceEqual(obs1, obs4)
                .subscribe(s -> System.out.println("Received: " + s));


    }


}
