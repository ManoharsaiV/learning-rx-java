package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

public class Chapter226 {
    public static void main(String[] args) {
      /*  Observable.just(1 / 0)
                .subscribe(System.out::println, e -> System.out.println("exception captured " + e));
*/
        Observable.just(1)
                .map(i -> (i / 0))
                .subscribe(System.out::println, e -> System.out.println("exception captured " + e));

        /*
         * Now, back to the exception in the just() method.
         * If you want it to be emitted down the Observable chain along with an onError event,
         * even if thrown during the emission initialization, use Observable.fromCallable() instead.
         * It accepts a functional interface, Supplier<T>. For example, we have the following:
         *
         * That is better! The error was emitted to the Observer rather than being thrown without being emitted.
         * If initializing your emission has a likelihood of throwing an error, use Observable.fromCallable()
         * instead of Observable.just().
         *  */

        Observable.fromCallable(() -> 1 / 0)
                .subscribe(System.out::println, e -> System.out.println("exception captured " + e));


    }
}
