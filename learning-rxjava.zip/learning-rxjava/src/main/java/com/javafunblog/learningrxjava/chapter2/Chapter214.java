package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.observables.ConnectableObservable;

public class Chapter214 {
    public static void main(String[] args) {
        ConnectableObservable<String> source =
                Observable.just("Alpha", "Beta", "Gamma").publish();
        //Set up observer 1
        source.subscribe(s -> System.out.println("Observer 1: " + s));
        //Set up observer 2

        source.map(String::length)
                .subscribe(i -> System.out.println("Observer 2: " + i));
        //Fire!
        source.connect();
    }
}
// Note how one Observer is receiving a String value, while the other is receiving an integer (the String value length)
// and the two are printing them in an interleaved fashion.
// Both subscriptions are set up in advance, before the connect() method is called to fire the emissions.

// Rather than Observer 1 processing all the emissions before Observer 2,
// each emission goes to all observers simultaneously.
// Using ConnectableObservable to force each emission to go to all observers is known as multicasting,


