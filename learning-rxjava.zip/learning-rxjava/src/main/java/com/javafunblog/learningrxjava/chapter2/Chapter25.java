package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

public class Chapter25 {
    public static void main(String[] args) {
        // just(..) can take a max of 10 values
        // it returns an Observable by combining all those values
        Observable<String> source =
                Observable.just("Alpha", "Beta", "Gamma");
        source.map(String::length).filter(i -> i >= 5)
                .subscribe(s -> System.out.println("RECEIVED: " + s));
    }
}
