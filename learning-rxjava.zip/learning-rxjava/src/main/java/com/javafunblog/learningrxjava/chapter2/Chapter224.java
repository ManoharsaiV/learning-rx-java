package com.javafunblog.learningrxjava.chapter2;

import io.reactivex.rxjava3.core.Observable;

public class Chapter224 {
    private static int start = 1;
    private static int count = 3;

    public static void main(String[] args) {
        Observable<Integer> source = Observable.range(start, count);
        source.subscribe(i -> System.out.println("Observer 1: " + i));
        //modify count
        count = 5;
        // If you subscribe to this Observable, modify the count,
        // and then subscribe again, you will find that the second Observer does not see this change:
        source.subscribe(i -> System.out.println("Observer 2: " + i));
        /*To remedy this problem of Observable sources not capturing state changes,
        you can create a fresh Observable for each subscription.
        This can be achieved using Observable.defer(), which accepts a lambda expression.
        This lambda creates an Observable for every subscription and, thus, reflects any change in its parameters:*/
        Observable<Integer> integerObservable = Observable.defer( () -> Observable.range(start, count));
        count = 5;
        integerObservable.subscribe(i -> System.out.println("Observer 3: " + i));
    }


}
